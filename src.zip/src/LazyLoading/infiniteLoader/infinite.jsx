import React from 'react'
import Home from './Home'

const Infinite = () => {
  return (
    <div>
      <Home/>
    </div>
  )
}

export default Infinite
